#!/usr/bin/env bash
# Telegram Wiki Bot Installer with AI Self-Healing Monitor and Codespace Setup
# This script automates deployment of the Telegram Wiki Bot skeleton to Fly.io,
# creates a GitHub repository if necessary, pushes code, spins up a Codespace,
# and starts a monitor that uses OpenAI GPT-4o-mini to suggest and optionally
# execute fixes for deployment errors.

set -euo pipefail

# Configurable variables
PROJECT_NAME="telegram-wiki-bot"
LOG_FILE="$HOME/${PROJECT_NAME}_install.log"
LOCAL_OAUTH_PORT=51723  # port for local OAuth callback server for OpenAI (if using OAuth)

# Colours for logging
G="\033[0;32m"; Y="\033[1;33m"; R="\033[0;31m"; N="\033[0m"

log() { echo -e "${G}[+] $*${N}" | tee -a "$LOG_FILE"; }
warn() { echo -e "${Y}[!] $*${N}" | tee -a "$LOG_FILE"; }
err() { echo -e "${R}[-] $*${N}" | tee -a "$LOG_FILE"; }

# Helper to open URLs in Termux or default environment
open_url() {
  local url="$1"
  if command -v termux-open >/dev/null 2>&1; then
    termux-open "$url" >/dev/null 2>&1 || true
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$url" >/dev/null 2>&1 || true
  else
    warn "Open this URL manually: $url"
  fi
}

# 1. Ensure log file exists
mkdir -p "$(dirname "$LOG_FILE")"
touch "$LOG_FILE"
log "Installer log at $LOG_FILE"

# 2. Detect package manager and install dependencies
PM=""
if command -v pkg >/dev/null 2>&1; then
  PM="pkg"
elif command -v apt-get >/dev/null 2>&1; then
  PM="apt-get"
fi

install_pkg() {
  local pkg_name="$1"
  if ! command -v $pkg_name >/dev/null 2>&1; then
    warn "$pkg_name not found. Installing..."
    if [ "$PM" = "pkg" ]; then
      pkg install -y $pkg_name
    elif [ "$PM" = "apt-get" ]; then
      sudo apt-get install -y $pkg_name
    else
      err "Unsupported package manager. Please install $pkg_name manually."
      exit 1
    fi
  fi
}

log "Updating packages..."
if [ "$PM" = "pkg" ]; then
  pkg update -y || true
elif [ "$PM" = "apt-get" ]; then
  sudo apt-get update -y || true
else
  warn "Unknown package manager. Please ensure system packages are up to date."
fi

install_pkg git
install_pkg curl
install_pkg nodejs
install_pkg npm
install_pkg jq

# Install Fly.io CLI if not present
if ! command -v fly >/dev/null 2>&1; then
  log "Installing Fly.io CLI (flyctl)..."
  curl -L https://fly.io/install.sh | sh
  export PATH="$HOME/.fly/bin:$PATH"
fi

# Install GitHub CLI if not present
if ! command -v gh >/dev/null 2>&1; then
  log "Installing GitHub CLI (gh)..."
  if [ "$PM" = "pkg" ]; then
    pkg install -y gh
  elif [ "$PM" = "apt-get" ]; then
    sudo apt-get install -y gh
  else
    err "Please install GitHub CLI manually."
    exit 1
  fi
fi

# 3. Authenticate GitHub
log "Authenticating with GitHub using gh..."
if ! gh auth status >/dev/null 2>&1; then
  warn "You need to authenticate with GitHub. A browser window may open for OAuth."
  gh auth login --web || { err "GitHub authentication failed"; exit 1; }
fi

# Determine your GitHub username
GH_USER=$(gh api user --jq '.login') || GH_USER=""
if [ -z "$GH_USER" ]; then
  err "Could not determine GitHub username via gh"
  exit 1
fi
log "Authenticated as GitHub user: $GH_USER"

# 4. Create or select remote repository
REMOTE_REPO="$GH_USER/$PROJECT_NAME"

# Check if repo already exists
if gh repo view "$REMOTE_REPO" >/dev/null 2>&1; then
  log "Repository $REMOTE_REPO already exists on GitHub"
else
  log "Creating repository $REMOTE_REPO on GitHub..."
  gh repo create "$REMOTE_REPO" --public --source . --remote origin --push || { err "Failed to create repository"; exit 1; }
fi

# 5. Push local code to remote (if not already)
log "Pushing local code to remote repository..."
# Ensure remote origin is set
if ! git remote | grep -q '^origin$'; then
  git remote add origin "https://github.com/$REMOTE_REPO.git"
fi
# Push main branch; fallback to master
if git rev-parse --verify main >/dev/null 2>&1; then
  git push -u origin main || true
elif git rev-parse --verify master >/dev/null 2>&1; then
  git push -u origin master || true
else
  git push -u origin HEAD:main || true
fi

# 6. Create Codespace and connect via SSH
log "Creating a Codespace for $REMOTE_REPO..."
CS_NAME="$(gh codespace create --repo "$REMOTE_REPO" --machine defaultLinux --format json --json name | jq -r '.name')"
if [ -z "$CS_NAME" ]; then
  err "Failed to create Codespace"
  exit 1
fi
log "Codespace created: $CS_NAME"

log "Opening Codespace via SSH in this terminal..."
warn "You will now enter the Codespace environment. To return to the installer after exiting the Codespace shell, type 'exit'."
gh codespace ssh -c "$CS_NAME"

# Return from codespace
log "Returned from Codespace shell. Continuing deployment..."

# 7. Authenticate with Fly.io
log "Authenticating with Fly.io..."
if ! fly auth whoami >/dev/null 2>&1; then
  warn "Logging into Fly.io via browser..."
  fly auth login || { err "Fly.io authentication failed"; exit 1; }
fi

# 8. Initialize Fly app
APP_NAME="$PROJECT_NAME"
if ! fly apps list | grep -q "^$APP_NAME"; then
  log "Launching Fly app $APP_NAME..."
  fly launch --name "$APP_NAME" --no-deploy || true
else
  log "Fly app $APP_NAME already exists"
fi

# 9. Collect secrets for environment
ENV_FILE=".env"
log "Collecting environment secrets..."

read -p "Enter your Telegram Bot Token: " TELEGRAM_BOT_TOKEN
read -p "Enter your Telegram owner user ID: " OWNER_USER_ID
read -p "Enter your Google AI API Key: " GOOGLE_AI_API_KEY
read -p "Enter your Notion API Key: " NOTION_API_KEY
read -p "Enter your GitHub Token (Classic, repo scope): " GITHUB_TOKEN
read -p "Enter your OpenAI API Key (sk-...): " OPENAI_API_KEY

cat > "$ENV_FILE" <<EOF
TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}
OWNER_USER_ID=${OWNER_USER_ID}
GOOGLE_AI_API_KEY=${GOOGLE_AI_API_KEY}
NOTION_API_KEY=${NOTION_API_KEY}
GITHUB_TOKEN=${GITHUB_TOKEN}
OPENAI_API_KEY=${OPENAI_API_KEY}
NODE_ENV=production
